<?php
/**
 * @var array $_CONFIG
 */
# PLEASE READ ALL THE COMMENTS TO HELP YOU LEARN HOW TO CONFIGURE SHADOW'S DASH.
# NO HELP WILL BE PROVIDED IF THE QUESTION CAN BE ANSWERED IN THIS CONFIG FILE.
# ============================================
# Thanks for installing Shadow's Dash!
# This is your configuration file. You can learn
# more about what you can do in the documentation.
# 
# This file is included in 90% of the pages. You can access them using the '$_CONFIG' variable. 
#
# <!> This is not the place to edit eggs or nodes.
# There should be a table for the respective features.
#

