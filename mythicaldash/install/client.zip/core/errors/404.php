<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 | NOT FOUND</title>
    <link rel="shortcut icon" type="https://ignition-development.xyz/cdn/slake/images/logo.svg">
    <link rel="stylesheet" href="https://ignition-development.xyz/cdn/slake/css/errors.css">
</head>
<body>
<div class="flex-container">
  <div class="text-center">
    <h1>
      <span class="fade-in" id="digit1">4</span>
      <span class="fade-in" id="digit2">0</span>
      <span class="fade-in" id="digit3">4</span>
    </h1>
    <h3 class="fadeIn">NOT FOUND</h3>
    <a href="/"><button type="button" name="button">Return To Home</button></a>
  </div>
</div>
</body>
</html>