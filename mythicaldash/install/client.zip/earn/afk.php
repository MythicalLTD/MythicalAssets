<?php
require("../core/require/page.php");
function Dashlog($text) {
    $time = date('Y-m-d H:i:s');
    $filepath ='../core/tmp/logs.txt';
    $handle = fopen($filepath, 'a');
    fwrite($handle, $time . ' | [AFK] '.$text . PHP_EOL);
    fclose($handle);
}

//require("function.php")
//$userdb = mysqli_query($cpconn, "SELECT * FROM users where discord_id = '". $_SESSION["user"]->id. "'")->fetch_object();
//$cpconn->query("INSERT INTO afk_data (discord_id, isafk) VALUES ('$user->id', '1')");
//
$userdb = $cpconn->query("SELECT * FROM users WHERE discord_id = '" . mysqli_real_escape_string($cpconn, $_SESSION["user"]->id) . "'")->fetch_array();
$stconn = $cpconn->query("SELECT * FROM settings")->fetch_array();

$usrcoins = $userdb['coins'];
$usrafkmin = $userdb['minutes_idle'];
Dashlog('(STATUS) '.'The user '.$userdb['discord_name'].' is now afk');
?>
 <!--<script>
            setTimeout(function() {
                window.location.href=".php";
            }, 60000);
        </script> -->

<!-- Header -->
<meta http-equiv="refresh" content="62">
<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 text-white d-inline-block mb-0">Earn coins</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="/"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Earn coins</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<input id="node" name="node" type="hidden" value="">
<!-- Page content -->
<div class="container-fluid mt--6">
    <div class="row justify-content-center">
        <div class="col-lg-8 card-wrapper">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0"><img src="https://i.imgur.com/jv3Frir.png" width="30">You are earning coins now</h3>
                </div>
                <div class="card-body" style="text-align: center;">
                    <p>For every minute you idle here, you get one coin. With those coins that you earn, you can purchase things from the shop. </p>
                    <p>You currently have <?php echo $usrcoins; ?> coin(s)!</p>
                    <p>You have been idling for <?php echo $usrafkmin; ?> minute(s)!</p>
                    <p>You will get more coins in <span id="timer"></span>!</p>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <footer class="footer pt-0">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6">
                <div class="copyright text-center  text-lg-left  text-muted">
                    Copyright &copy;2022-2023 <a href="https://github.com/NaysDevelopment/NaysDash" class="font-weight-bold ml-1" target="_blank">ShadowDash x NaysDash </a> - Theme by <a href="https://creativetim.com" target="_blank">Creative Tim</a>
                </div>
            </div>
            <div class="col-lg-6">
                <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["website"] ?>" class="nav-link" target="_blank"> Website</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["statuspage"] ?>" class="nav-link" target="_blank">Uptime / Status</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["privacypolicy"] ?>" class="nav-link" target="_blank">Privacy policy</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["termsofservice"] ?>" class="nav-link" target="_blank">Terms of service</a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
    </div>
    </div>
    <?php echo '<script>';
echo "setInterval(function () { $.ajax({ url: '../core/afk/functions/coins.php', success: function (data) { console.log(\"Earned A Coin!\"); } }); }, 60000)";
echo '</script>';
?>
<script>
    setInterval(function () {
        $('#stats').load(location.href + " #stats>*", "")
    }, 61000)

</script>
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/vendor/jquery/dist/jquery.min.js"></script>
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/vendor/js-cookie/js.cookie.js"></script>
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
    <!-- Optional JS -->
    <script src="/core/afk/functions/timer.js"></script>
    </script>
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/vendor/sweetalert2/dist/sweetalert2.min.js"></script>
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/vendor/bootstrap-notify/bootstrap-notify.min.js"></script>
    <!-- Argon JS -->
    <script src="https://525631ac.mythicalassets.pages.dev/mythicaldash/js/argon.js?v=1.2.0"></script>
</div>

</html>
