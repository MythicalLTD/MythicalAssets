<?php
require("../core/require/page.php");

?>