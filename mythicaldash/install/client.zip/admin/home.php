<?php 
require("../core/require/page.php");


$usrdb = $cpconn->query("SELECT * FROM users where discord_id = '". $_SESSION["user"]->id. "'")->fetch_array();
//Looks into perms if users has acces to see this page!
$perms = $cpconn->query("SELECT * FROM roles WHERE name='".$usrdb['role']."'")->fetch_array();



if ($perms['canseeadminhomepage'] == "true" || $perms['fullperm'] == "true")
{

}
else
{
  echo '<script>window.location.replace("/");</script>';
  $_SESSION['error'] = "You are not allowed to see this page";
  die;
}

$sqlurs = "SELECT COUNT(*) FROM users";
$resultusrs = mysqli_query($cpconn, $sqlurs);
$countusrs = mysqli_fetch_array($resultusrs)[0];

$sqlsvs = "SELECT COUNT(*) FROM servers";
$resultsvs = mysqli_query($cpconn, $sqlsvs);
$countsvs = mysqli_fetch_array($resultsvs)[0];

$sqlsvsq = "SELECT COUNT(*) FROM servers_queue";
$resultsvsq = mysqli_query($cpconn, $sqlsvsq);
$countsvsq = mysqli_fetch_array($resultsvsq)[0];

$sqlloc = "SELECT COUNT(*) FROM locations";
$resultloc = mysqli_query($cpconn, $sqlloc);
$countlocations = mysqli_fetch_array($resultloc)[0];

$sqleggs = "SELECT COUNT(*) FROM eggs";
$resulteggs = mysqli_query($cpconn, $sqleggs);
$counteggs = mysqli_fetch_array($resulteggs)[0];

$sqlroles = "SELECT COUNT(*) FROM roles";
$resultroles = mysqli_query($cpconn, $sqlroles);
$countroles = mysqli_fetch_array($resultroles)[0];

?>

<body class="bg-dark text-light">
  <div class="container-fluid text-center bg-dark text-light py-4">
    <h1>Welcome to the Admin Page</h1>
    <p>Here you can manage users, manage servers, and change settings for the application.</p>
    
  </div>
<div class="container mt-5">
  <div class="row">
    <div class="col-md-2">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Users</h5>
          <!-- Display the total number of users -->
          <h1 class="card-text"><?= $countusrs ?></h1>
          
          <?php 
          if ($perms['canseeusers'] == "true" || $perms['fullperm'] == "true" || $perms['caneditusers'] == "true" || $perms['candeleteusers'] == "true")
          {
            ?>
            <a href="users.php" class="btn btn-primary">View all</a>
            <?php
          }
          else
          {
            
          }          
          ?>
        </div>
      </div>
    </div>
    <div class="col-md-2">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Servers</h5>
          <h1 class="card-text"><?= $countsvs ?></h1>
          <?php 
          if ($perms['canseeservers'] == "true" || $perms['fullperm'] == "true" || $perms['caneditservers'] == "true" || $perms['caneditservers'] == "true")
          {
            ?>
              <a href="servers.php" class="btn btn-primary">View all</a>
            <?php
          }
          ?>
          
        </div>
      </div>
    </div>
    <div class="col-md-2">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Servers In queue</h5>
          <h1 class="card-text"><?= $countsvsq ?></h1>
          <a href="servers_queue.php" class="btn btn-primary">View all</a>
        </div>
      </div>
    </div>
    <div class="col-md-2">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Coupons</h5>
          <h1 class="card-text"><?= $countlocations ?></h1>
          <a href="#" class="btn btn-primary">View all</a>
        </div>
      </div>
    </div>
    <div class="col-md-2">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Eggs</h5>
          <h1 class="card-text"><?= $counteggs ?></h1>
          <a href="#" class="btn btn-primary">View all</a>
        </div>
      </div>
    </div>
    <div class="col-md-2">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Roles</h5>
          <h1 class="card-text"><?= $countroles ?></h1>
          <a href="#" class="btn btn-primary">View all</a>
        </div>
      </div>
    </div>
  </div>
</div>
