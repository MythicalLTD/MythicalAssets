<?php 
require("../require/page.php");


$usrdb = $cpconn->query("SELECT * FROM users where discord_id = '". $_SESSION["user"]->id. "'")->fetch_array();
//Looks into perms if users has acces to see this page!
$perms = $cpconn->query("SELECT * FROM roles WHERE name='".$usrdb['role']."'")->fetch_array();



if ($perms['caneditappsettings'] == "true" || $perms['fullperm'] == "true")
{

}
else
{
  echo '<script>window.location.replace("/");</script>';
  $_SESSION['error'] = "You are not allowed to see this page";
  die;
}
?>
<body class="bg-dark text-light">
  <div class="container-fluid text-center bg-dark text-light py-4">
    <h1>Welcome to the settings page</h1>
    <p>Here you can manage the dashboard change settings and update the files and the database!</p>
  </div>
  

</body>

<div class="container mt-5">
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <div class="card-header">
            Quick settings
          </div>
          <div class="card-body">
            <form action="settings" method="GET">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" name="statmaintenance" id="maintenance">
                  <label class="custom-control-label" for="maintenance">Enable maintenance</label>
                </div>
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" name="svcreation" checked="true" id="servercreation">
                  <label class="custom-control-label" for="servercreation">Server creation</label>
                </div>
                <br>
                <button name="submit" value="yes" class="btn btn-primary btn-block">Update</button>
            </form>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-header">
            Settings 2
          </div>
          <div class="card-body">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-header">
            Settings 3
          </div>
          <div class="card-body">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--<div class="container mt-5 text-center">
  <div class="row">
    <div class="col-sm-6 offset-sm-3">
      <h1>Application Settings</h1>

      <form>
        <div class="form-group">
          <label for="appName">Application Name</label>
          <input type="text" class="form-control form-control-sm" id="appName" placeholder="Enter application name">
        </div>
        <div class="form-group form-check">
          <input type="checkbox" class="form-check-input" id="maintenanceMode">
          <label class="form-check-label" for="maintenanceMode">Enable Maintenance Mode</label>
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </form>
    </div>
  </div>
</div>-->
