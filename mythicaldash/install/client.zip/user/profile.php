<?php 
require('../core/require/page.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$userdb = $cpconn->query("SELECT * FROM users WHERE discord_id = '" . $_SESSION['user']->id . "'")->fetch_object();
$newuser = $cpconn->query("SELECT * FROM users WHERE discord_id = '" . $_SESSION['user']->id . "'")->fetch_assoc();
$avatar = $newuser['avatar'];
if ($newuser['staff'] == "1")
{
    $isstaff = "true";
}
else
{
    $isstaff = "false";
}
?>
<style>

</style>

    <!-- Header -->
    <div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="min-height: 600px; background-image: url(<?= $newuser['background'] ?>); background-size: cover; background-position: center top;">
      <!-- Mask -->
      <span class="mask bg-gradient-default opacity-8"></span>
      <!-- Header container -->
      
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--9">
      <div class="row">
        <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
          <div class="card card-profile shadow">
            <div class="row justify-content-center">
              <div class="col-lg-3 order-lg-2">
                <div class="card-profile-image">
                  <a href="#">
                    <img src="<?= $avatar ?>" class="rounded-circle">
                  </a>
                </div>
              </div>
            </div>
            <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
              <div class="d-flex justify-content-between">
                <!-- I dont know if i will use this design
                <a href="#" class="btn btn-sm btn-info mr-4">Connect</a>
                <a href="#" class="btn btn-sm btn-default float-right">Message</a>-->
              </div>
            </div>
            <div class="card-body pt-0 pt-md-4">
              <div class="text-center">
                <h3>
                  <?= $newuser['discord_name']?><span class="font-weight-light">
                </h3>
                <div class="h5 font-weight-300">
                  <?= $newuser['role']?>
                </div>
                <div class="h5 mt-4">
                  Account Created: <?= $newuser['registered']?>
                </div>
                <hr class="my-4" />
                <p><?= $newuser['aboutme'] ?></p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-8 order-xl-1">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-dark border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Your account:</h3>
                </div>
              </div>
            </div>
            <div class="card-body bg-dark text-white">
              <form>
                <h6 class="heading-small mb-4 text-white text-center">User information</h6>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label text-white" for="input-username">Username</label>
                        <h1 class="form-control"><?= $newuser['discord_name']?></h1>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label text-white" for="input-email">Email address</label>
                        <h1 class="form-control"><?= $newuser['discord_email']?></h1>
                      </div>
                    </div>
                  </div>
                </div>
                <hr class="my-4" />
                <h6 class="heading-small text-muted mb-4 text-center text-white">About me</h6>
                <div class="pl-lg-4">
                  <div class="form-group focused">
                    <label for="accountstatus">Account Visibility</label>
                    <select class="form-control" value="<?php $newuser['visibility'] ?>" name="accountstatus">
                    <?php 
                    if ($newuser['visibility'] == "Public")
                    {
                        echo '
                        <option value="public">Public</option>
                        <option value="private">Private</option>
                        ';
                    }
                    else 
                    {
                        echo '
                        <option value="private">Private</option>
                        <option value="public">Public</option>
                        ';
                    }
                    ?>
                     
                    </select>
                    <br>
                    <label>Profile Background</label>
                    <input type="text" id="input-last-name" class="form-control " placeholder="https://yourcdn.net/pic/cutecatto.png" value="<?= $newuser['background']?>">
                    <br>
                    <label>About Me</label>
                    <textarea rows="3" class="form-control" placeholder="A few words about you ..."><?= $newuser['aboutme'] ?></textarea>
                  </div>
                </div>
                <hr class="my-4" />
                <button class="btn btn-lg btn-primary" style="width:100%;" name="submit" type="submit">Update!</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <footer class="footer pt-0">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6">
                <div class="copyright text-center  text-lg-left  text-white">
                    Copyright &copy;2022-2023 <a href="https://github.com/NaysDevelopment/NaysDash" class="font-weight-bold ml-1" target="_blank">ShadowDash x NaysDash </a> - Theme by <a href="https://creativetim.com" target="_blank">Creative Tim</a>
                </div>
            </div>
            <div class="col-lg-6">
                <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["website"] ?>" class="nav-link" target="_blank"> Website</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["statuspage"] ?>" class="nav-link" target="_blank">Uptime / Status</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["privacypolicy"] ?>" class="nav-link" target="_blank">Privacy policy</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["termsofservice"] ?>" class="nav-link" target="_blank">Terms of service</a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
<script src="/app-assets/vendors/js/vendors.min.js"></script>
<!-- <script src="/app-assets/vendors/js/charts/apexcharts.min.js"></script> -->
<!-- <script src="/app-assets/vendors/js/extensions/tether.min.js"></script> -->
<!-- <script src="/app-assets/vendors/js/extensions/shepherd.min.js"></script> -->
<script src="/app-assets/js/core/app-menu.js"></script>
<script src="/app-assets/js/core/app.js"></script>
<script src="/app-assets/js/scripts/components.js"></script>
<!-- <script src="/app-assets/js/scripts/pages/dashboard-analytics.js"></script> -->
<script src="/app-assets/vendors/js/forms/select/select2.full.min.js"></script>
<script src="/app-assets/js/scripts/forms/select/form-select2.js"></script>
</body>

</html>