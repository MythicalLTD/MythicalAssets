<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require('../core/require/page.php');
$usrdb = $cpconn->query("SELECT * FROM users where discord_id = '". $_SESSION["user"]->id. "'")->fetch_array();
if (isset($_POST['submit'])) {
    $newpassword = $_POST['newpass'];
    $ch = curl_init($getsettingsdb["ptero_url"] . "/api/application/users/".$usrdb['panel_id']);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer ' . $getsettingsdb["ptero_apikey"],
        'Content-Type: application/json',
        'Accept: application/json'
    ));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
        'username' => $usrdb['panel_username'],
        'first_name' =>  $_SESSION["user"]->username,
        'last_name' => $getsettingsdb["name"],
        'email' => $_SESSION["user"]->email,
        'password' => $newpassword,
        'language' => 'en'
    )));
    $updateUserResult = curl_exec($ch);
    curl_close($ch);
    $updateUserResult = json_decode($updateUserResult, true);

    if (!isset($updateUserResult['object'])) {
        if(curl_errno($ch)){
            $_SESSION["error"] = "An error occured while doing the request: " . curl_error($ch);
        }
    }
    else {
        $_SESSION["success"] = "Your password got changed successfully";
        if (mysqli_query($cpconn, "UPDATE `users` SET `panel_password` = '".$newpassword."' WHERE `users`.`id` = ".$usrdb['id'].";")) {
        }
        else {
            $_SESSION['error'] = "There was an unexpected error while reseting your password!";
        }
    
        $_SESSION['success'] = "We changed your password";
        //echo '<script>window.location.replace("/");</script>';
        //die();
    }


    
}
?>
<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 text-white d-inline-block mb-0">Account </h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="/"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Password reset</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<input id="node" name="node" type="hidden" value="">

<div class="container-fluid mt--6">
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <section id="dashboard-analytics">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="mb-0 text-center">Change password for the account "<?= $usrdb['discord_name'] ?>"</h4>
                                <h5 class="mb-0 text-center">Want to see your account name?  <a href="credentials.php">Do it right here</a></h5>
                            </div>
                            <div class="card-body">
                                <form action="" method="post">
                                    <label for="newpass">New password:</label>
                                    <input type="password" class="form-control" name="newpass" value="" required>
                                    <br>
                                    <button class="btn btn-lg btn-primary" style="width:100%;" name="submit" type="submit">Reset password!</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </section>
        </div>
        <div class="col-md-10">
    </div>
</div>

<!-- END: Content-->

<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<!-- BEGIN: Footer-->
<footer class="footer pt-0">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6">
                <div class="copyright text-center  text-lg-left  text-muted">
                    Copyright &copy;2022-2023 <a href="https://github.com/NaysDevelopment/NaysDash" class="font-weight-bold ml-1" target="_blank">ShadowDash x NaysDash </a> - Theme by <a href="https://creativetim.com" target="_blank">Creative Tim</a>
                </div>
            </div>
            <div class="col-lg-6">
                <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["website"] ?>" class="nav-link" target="_blank"> Website</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["statuspage"] ?>" class="nav-link" target="_blank">Uptime / Status</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["privacypolicy"] ?>" class="nav-link" target="_blank">Privacy policy</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= $getsettingsdb["termsofservice"] ?>" class="nav-link" target="_blank">Terms of service</a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
<script src="/app-assets/vendors/js/vendors.min.js"></script>
<!-- <script src="/app-assets/vendors/js/charts/apexcharts.min.js"></script> -->
<!-- <script src="/app-assets/vendors/js/extensions/tether.min.js"></script> -->
<!-- <script src="/app-assets/vendors/js/extensions/shepherd.min.js"></script> -->
<script src="/app-assets/js/core/app-menu.js"></script>
<script src="/app-assets/js/core/app.js"></script>
<script src="/app-assets/js/scripts/components.js"></script>
<!-- <script src="/app-assets/js/scripts/pages/dashboard-analytics.js"></script> -->
<script src="/app-assets/vendors/js/forms/select/select2.full.min.js"></script>
<script src="/app-assets/js/scripts/forms/select/form-select2.js"></script>
</body>

</html>