# NaysDash
A fully customizable shared-resources based dashboard for pterodactyl hosting services 

## Documentation
<p align="center"><a href=""><img src="https://i.imgur.com/IJnJnTA.png" width=20%></a></p>

# 🗃️ Features
Theses features are the basic ones. In the future, more features are likely to come.
| Feature                            | Available |
|------------------------------------|-----------|
| Auto installer                     | 🔃         |
| Server creation                    | ✔️         |
| Server editing                     | ✔️         |
| Server deletion                    | ✔️         |
| Server Fetch                       | ✔️         |
| Server enaming                     | ✔️         |
| Panel credentials                  | ✔️         |
| Login                              | ✔️         |
| Login queue                        | ✔️         |
| Discord oAuth handler              | ✔️         |
| Earning coins                      | ✔️         |
| Resources shop                     | ✔️         |
| Full customization                 | ✔️         |
| Full navbar control                | ✔️         |
| Full login control                 | ✔️         |
| Add & Remove Coins                 | ✔️         |
| AFK Page                           | ✔️         |
| Custom Error Page                  | ✔️         |
| Custom panel credentials           | 🔃         |
| Profile Page                       | 🔃         |
| Admin page                         | 🔃         |
| Reedem Page                        | ❌         |
| Register & Login(NON DISCORD)      | ❌         |

## Credit
You must keep the **Powered by ShadowsDash & NaysDash**

# 🎨 Frontend
The frontend is a free theme called: [Argon Dashboard](https://www.creative-tim.com/product/argon-dashboard)

# 👔 Contributing
NaysDash is open for contributions! Feel free to help! :)

<hr>

**Copyright (c) 2022 NaysDash** </br> 
</br>
**Copyright (c) 2022 ShadowsDash**
