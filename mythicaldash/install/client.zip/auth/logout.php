<?php
function Dashlog($text) {
    $time = date('Y-m-d H:i:s');
    $filepath ='../core/tmp/logs.txt';
    $handle = fopen($filepath, 'a');
    fwrite($handle, $time . ' | [AUTH] '.$text . PHP_EOL);
    fclose($handle);
}
session_start();
require("../core/require/sql.php");
$userdb = $cpconn->query("SELECT * FROM users WHERE discord_id = '" . mysqli_real_escape_string($cpconn, $_SESSION["user"]->id) . "'")->fetch_array();
Dashlog('(SUCCESS) '.$userdb["discord_name"].' logged out');
session_destroy();
echo '<script>window.location.replace("/");</script>';
?>