<?php 
require("../core/require/page.php");
$usrdb = $cpconn->query("SELECT * FROM users where discord_id = '". $_SESSION["user"]->id. "'")->fetch_array();
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
$cpuprice = $getsettingsdb["cpuprice"];
$ramprice = $getsettingsdb["ramprice"];
$diskprice = $getsettingsdb["diskprice"];
$svprice = $getsettingsdb["svslotprice"];

$usr_coins = $usrdb['coins'];
$usr_cpu = $usrdb["cpu"];
$usr_ram = $usrdb["memory"];
$usr_disk = $usrdb["disk_space"];
$usr_svlimit = $usrdb["server_limit"];

if (isset($_GET["buycpu"])) {
  if ($usr_coins >= $cpuprice) {
    //new coins
    $newcoins = $usr_coins - $cpuprice;
    $newcpu = $usr_cpu + "100";
    mysqli_query($cpconn, "UPDATE `users` SET `cpu` = '" . $newcpu . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    mysqli_query($cpconn, "UPDATE `users` SET `coins` = '" . $newcoins . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    $_SESSION['success'] = "Thanks for your purchase, we updated your resources!";
  }
  else
  {
    $_SESSION['error'] = "You dont have coins to buy this!";
  }
}

if (isset($_GET["buyram"])) {
  if ($usr_coins >= $ramprice) {
    //new coins
    $newcoins = $usr_coins - $ramprice;
    $newram = $usr_ram + "1024";
    mysqli_query($cpconn, "UPDATE `users` SET `memory` = '" . $newram . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    mysqli_query($cpconn, "UPDATE `users` SET `coins` = '" . $newcoins . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    $_SESSION['success'] = "Thanks for your purchase, we updated your resources!";
  }
  else
  {
    $_SESSION['error'] = "You dont have coins to buy this!";
  }
}

if (isset($_GET["buydisk"])) {
  if ($usr_coins >= $diskprice) {
    //new coins
    $newcoins = $usr_coins - $diskprice;
    $newdisk = $usr_disk + "1024";
    mysqli_query($cpconn, "UPDATE `users` SET `disk_space` = '" . $newdisk . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    mysqli_query($cpconn, "UPDATE `users` SET `coins` = '" . $newcoins . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    $_SESSION['success'] = "Thanks for your purchase, we updated your resources!";
  }
  else
  {
    $_SESSION['error'] = "You dont have coins to buy this!";
  }
}

if (isset($_GET["buysv"])) {
  if ($usr_coins >= $svprice) {
    //new coins
    $newcoins = $usr_coins - $svprice;
    $newsv = $usr_svlimit + "1";
    mysqli_query($cpconn, "UPDATE `users` SET `server_limit` = '" . $newsv . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    mysqli_query($cpconn, "UPDATE `users` SET `coins` = '" . $newcoins . "' WHERE `users`.`discord_id` = " . $_SESSION["user"]->id);
    $_SESSION['success'] = "Thanks for your purchase, we updated your resources!";
  }
  else
  {
    $_SESSION['error'] = "You dont have coins to buy this!";
  }
}

?>
<style>
.card-img-top {
 height: 140px;
 width: 160px;
}
.card-footer {
  display: flex;
  justify-content: space-between;
}
</style>

<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 text-white d-inline-block mb-0">Coins shop</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="/"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Coins shop</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<input id="node" name="node" type="hidden" value="">


<div class="container-fluid mt--6">
    <div class="row justify-content-center">
    <div class="col-md-12">
            </div>
        <div class="col-lg-8 card-wrapper">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0"><img src="https://i.imgur.com/2WYzXDV.png" width="30"> Coins shop</h3>
                    
                </div>
                
                <div class="card-body" style="text-align: center;">
                <?php
                if (isset($_SESSION["error"])) {
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <strong>Error!</strong> <?= $_SESSION["error"] ?>
                    </div>
                    <?php
                    unset($_SESSION["error"]);
                }
                ?>
                <?php
                if (isset($_SESSION["success"])) {
                    ?>
                    <div class="alert alert-success" role="alert">
                        <strong>Success!</strong> <?= $_SESSION["success"] ?>
                    </div>
                    <?php
                    unset($_SESSION["success"]);
                }
                ?>
                    <div class="row">
                          <div class="col-lg-3 col-md-6 mb-9">
                            <div class="h-100 text-center">
                              <a class="mx-auto text-center"><img class="card-img-top" src="https://i.imgur.com/b6TNCeZ.png" alt=""></a>
                              <div class="card-body">
                                <h4 class="card-title">
                                  <a>CPU</a>
                                </h4>
                                <h5><?= $cpuprice ?>€</h5>
                                <p class="card-text">For every <?= $cpuprice ?> coins you get 1VCore to use on your server / bot.</p>
                              </div>
                              <form action="resources" method="GET">
                              <div class="card-footer">
                                <button name="buycpu" value="yes" class="btn btn-primary btn-block">Buy</button>
                              </div>
                              </form>
                            </div>
                          </div>
                       
                          <div class="col-lg-3 col-md-6 mb-9">
                             <div class="h-100 text-center">
                              <a class="mx-auto text-center"><img class="card-img-top" src="https://i.imgur.com/sxZ4OB4.png" alt=""></a>
                              <div class="card-body">
                                <h4 class="card-title">
                                  <a>RAM</a>
                                </h4>
                                <h5><?= $ramprice ?>€</h5>
                                <p class="card-text">For every <?= $ramprice ?> coins you get 1GB ram to use on your application.</p>
                              </div>
                              <form action="resources" method="GET">
                              <div class="card-footer">
                                <button name="buyram" value="yes" class="btn btn-primary btn-block">Buy</button>
                              </div>
                              </form>
                            </div>
                          </div>
                        <div class="col-lg-3 col-md-6 mb-9">
                            <div class="h-100 text-center">
                              <a class="mx-auto text-center"><img class="card-img-top" src="https://i.imgur.com/N0MwF0M.png" alt=""></a>
                              <div class="card-body">
                                <h4 class="card-title">
                                  <a>Disk</a>
                                </h4>
                                <h5><?= $diskprice ?>€</h5>
                                <p class="card-text">For every <?= $diskprice ?> coins you get 1GB disk to use on your application.</p>
                              </div>
                              <form action="resources" method="GET">
                              <div class="card-footer">
                                <button name="buydisk" value="yes" class="btn btn-primary btn-block">Buy</button>
                              </div>
                              </form>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-9">
                          <div class="h-100 text-center">
                            <a class="mx-auto text-center"><img class="card-img-top" src="https://i.imgur.com/3w5wt0k.png" alt=""></a>
                            <div class="card-body">
                              <h4 class="card-title">
                                <a>Server Slot</a>
                              </h4>
                              <h5><?= $svprice ?>€</h5>
                              
                              <p class="card-text">For every <?= $svprice ?> coins you get 1 server slot to deploy your application.</p>
                            </div>
                            <form action="resources" method="GET">
                            <div class="card-footer">
                              <button name="buysv" value="yes" class="btn btn-primary btn-block">Buy</button>
                            </div>
                            </form>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
         
        </div>
    </div>
</div>

  <!-- Page Content -->
  <div class="container mt-5">
    <!-- Page Heading -->

    <!-- Products Grid -->

<!-- /.row -->

</div>
<!-- /.container -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.16.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</body>